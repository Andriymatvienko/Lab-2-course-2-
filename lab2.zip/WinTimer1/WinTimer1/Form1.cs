namespace WinTimer1
{
    public partial class WinTimer1 : Form
    {
        public WinTimer1()
        {
            InitializeComponent();
        }

        private void WinTimer1_Load(object sender, EventArgs e)
        {

        }
    }
}